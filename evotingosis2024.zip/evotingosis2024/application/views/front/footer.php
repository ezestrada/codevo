<footer class="footer bg-dark">
    <div class="container">
        <!-- Copyright -->
        <div class="footer-copyright text-center ">
            <p class="text-center text-white">Copyright &copy; <a style="text-decoration: none  !important" class="text-white" target="_blank" href="<?= site_url() ?>"><?= get_pengaturan('penyelenggara') ?></a>
                <script>
                    document.write(new Date().getFullYear());
                </script>
            </p>
        </div>
    </div>
</footer>