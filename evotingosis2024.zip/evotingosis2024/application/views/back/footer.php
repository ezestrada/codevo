<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0 beta
    </div>
    <strong>Copyright &copy; <script>
            document.write(new Date().getFullYear())
        </script> <a target="_blank" href="<?= site_url() ?>"><?= get_pengaturan('penyelenggara') ?></a></strong>
    All rights reserved.
</footer>