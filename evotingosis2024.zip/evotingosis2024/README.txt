# E-Voting

Aplikasi ini dibuat untuk meningkatkan kesadaran akan pentingnya menggunakan hak pilih kita dalam demokrasi di dunia yang modern ini.

# Server Requierment

PHP version 7.3 or newer

Database MySQL PHPMYADMIN

# Instalation

- ekstrak file eVoting ke dalam folder htdocs
- buat database baru dengan nama **evoting**
- import file **evoting.sql** ke database evoting yang sudah dibuat tadi
- **localhost/admin** untuk login ke dalam panel admin

# Setting Database

- Buat database evoting
- import file **vote.sql** ke database vote

# User

**Administrator**'

```
localhost/admin
E-mail: admin@admin.com
Password: admin123456
```